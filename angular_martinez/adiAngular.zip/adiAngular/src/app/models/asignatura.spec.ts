import { Asignatura } from './asignatura';

describe('Asignatura', () => {
  it('should create an instance', () => {
    expect(new Asignatura()).toBeTruthy();
  });
});
