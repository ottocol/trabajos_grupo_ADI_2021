import { Component, OnInit } from '@angular/core';
import { Asignatura } from '../../models/asignatura';
import { AsignaturaService } from '../../services/asignatura.service';

@Component({
  selector: 'app-listado',
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.css']
})
export class ListadoComponent implements OnInit {
  asignaturas: Asignatura[]

  constructor(private listadoService: AsignaturaService) {
  }

  ngOnInit(): void {
    this.asignaturas = this.listadoService.getAsignaturas();
  }

  deleteAsignatura(_id: number){
    this.listadoService.deleteAsignatura(_id);
  }
}
