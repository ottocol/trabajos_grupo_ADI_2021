export class Task {
    itemIndex: string;
    item: string;

    constructor(itemIndex:"",item:""){
        this.itemIndex = itemIndex;
        this.item = item;

    }
}
