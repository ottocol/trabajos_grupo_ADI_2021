import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListadoComponent } from './components/listado/listado.component';
import { CreacionComponent } from './components/creacion/creacion.component';

const routes: Routes = [
  { path: '', component: ListadoComponent },
  { path: 'listar', component: ListadoComponent },
  { path: 'editar/:id', component: CreacionComponent },
  { path: 'crear', component: CreacionComponent },
  { path: '**', redirectTo: '/', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
