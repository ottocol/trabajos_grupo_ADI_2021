export class Asignatura {
    id: number
    nombre: string
    descripcion: string
    creditos: number
    curso: number
    cuatrimestre: 'Primero' | 'Segundo'
}
