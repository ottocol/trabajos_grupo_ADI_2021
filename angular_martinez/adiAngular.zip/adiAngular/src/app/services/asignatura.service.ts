import { Injectable } from '@angular/core';
import { Asignatura } from '../models/asignatura';

const AsignaturasDefault : Asignatura[] = [
  {
    id: 1,
    nombre: 'ADI',
    descripcion: 'Aplicaciones Distribuidas en Internet',
    creditos: 6,
    curso: 4,
    cuatrimestre: 'Primero'
  },
  {
    id: 2,
    nombre: 'MADS',
    descripcion: 'Metodologías Ágiles de Desarrollo de Software',
    creditos: 6,
    curso: 4,
    cuatrimestre: 'Primero'
  },
  {
    id: 3,
    nombre: 'IW',
    descripcion: 'Ingeniería Web',
    creditos: 6,
    curso: 4,
    cuatrimestre: 'Primero'
  },
  {
    id: 4,
    nombre: 'DCA',
    descripcion: 'Desarrollo Colaborativo de Aplicaciones',
    creditos: 6,
    curso: 4,
    cuatrimestre: 'Primero'
  },
  {
    id: 5,
    nombre: 'P3',
    descripcion: 'Programación 3',
    creditos: 6,
    curso: 2,
    cuatrimestre: 'Primero'
  },
  {
    id: 6,
    nombre: 'PPSS',
    descripcion: 'Planificación y Pruebas de Sistemas Software',
    creditos: 6,
    curso: 3,
    cuatrimestre: 'Segundo'
  },
  {
    id: 7,
    nombre: 'ASORC',
    descripcion: 'Administración de Sistemas Operativos y Redes de Computadores',
    creditos: 6,
    curso: 3,
    cuatrimestre: 'Segundo'
  },
  {
    id: 8,
    nombre: 'TEST',
    descripcion: 'Transformación de las Estructuras de SubTareas',
    creditos: 6,
    curso: 4,
    cuatrimestre: 'Primero'
  },
]

const Asignaturas: Asignatura[] = JSON.parse(localStorage.getItem('asignaturas') ?? 'null') ?? AsignaturasDefault

function idDelUltimo() : number {
  return Asignaturas.reduce((res: number, a: Asignatura) => { return res > a.id ? res : a.id }, 0)
}

var nextId = idDelUltimo() + 1


@Injectable({
  providedIn: 'root'
})
export class AsignaturaService {

  constructor() {}

  getAsignaturas() {
    return Asignaturas;
  }

  getAsignatura(_id: number) {
    return Asignaturas.find(asignatura => asignatura.id == _id)
  }

  addAsignatura(asignatura: Asignatura) {
    asignatura.id = nextId++
    Asignaturas.push(asignatura)
    localStorage.setItem('asignaturas', JSON.stringify(Asignaturas))
  }

  editAsignatura(editAsignatura: Asignatura) {
    const index = Asignaturas.findIndex(asignatura => asignatura.id == editAsignatura.id)

    Asignaturas[index] = editAsignatura
    localStorage.setItem('asignaturas', JSON.stringify(Asignaturas))
  }

  deleteAsignatura(_id : number) {
    const index = Asignaturas.findIndex(asignatura => asignatura.id == _id)
    Asignaturas.splice(index, 1)
    localStorage.setItem('asignaturas', JSON.stringify(Asignaturas))
    if (_id == nextId - 1) nextId = idDelUltimo() + 1
  }

}
