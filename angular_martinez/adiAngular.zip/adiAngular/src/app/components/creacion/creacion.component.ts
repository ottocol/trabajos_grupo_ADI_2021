import { Component, OnInit } from '@angular/core';
import { AsignaturaService } from 'src/app/services/asignatura.service';
import { Asignatura } from '../../models/asignatura';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-creacion',
  templateUrl: './creacion.component.html',
  styleUrls: ['./creacion.component.css']
})
export class CreacionComponent implements OnInit {

  asignatura: Asignatura
  title: string

  constructor(
    private listadoService: AsignaturaService,
    private route: ActivatedRoute,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const id = params['id']
      if (id) {
        this.asignatura = this.listadoService.getAsignatura(id)
        this.title = 'Edición de la asignatura ' + this.asignatura.nombre
      }
      else {
        this.asignatura = new Asignatura();
        this.title = 'Creación de asignaturas'
      }
    });
  }

  enviar(): void {
    if (this.asignatura.id) {
      this.listadoService.editAsignatura(this.asignatura)
    }
    else {
      this.listadoService.addAsignatura(this.asignatura)
    }
    this.router.navigate(['/'])
  }

}
