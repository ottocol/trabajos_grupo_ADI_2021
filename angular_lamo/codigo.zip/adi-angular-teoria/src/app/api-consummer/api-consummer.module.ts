import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { ViewtaskComponent } from './component/viewtask/viewtask.component';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class ApiConsummerModule { }
